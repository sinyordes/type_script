import {createSlice} from "@reduxjs/toolkit";  //5

interface dataType{
    name:string,
    number:number

}

const veriler:dataType[]=[
    {name:"example1" , number:16},
    {name:"example2" , number:14}
]

const dataSlice:any= createSlice({
    name:'veriler',
    initialState:{
        data:veriler
    },
    reducers:{},


});

export default dataSlice.reducer;
