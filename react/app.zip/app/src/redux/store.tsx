import {configureStore} from "@reduxjs/toolkit"; //1

import dataSlice from "./slice";

export const store = configureStore({
//2
    reducer:{
        veriAl:dataSlice//7
    },


})