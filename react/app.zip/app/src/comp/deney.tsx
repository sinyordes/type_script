export interface veri<Type>{
    tur:Type;
}
export interface Metin{
    isim:string;
}

export type Yazi = veri<Metin>;


export function Deney(isim:Yazi){

    return(
        {isim}
    )
}