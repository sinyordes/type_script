import {useSelector} from "react-redux";
import {nanoid} from "@reduxjs/toolkit";
interface itemType{

    name:string,
    number:string

}

export  function ReduxComp(){
    const items:any = useSelector<any>(state=>state.veriAl.data)

    console.log(items)
    return (
        <>
        <div>{

            items.map(
                (item:itemType)=>(<h2 key={nanoid()} id={item.number}>{item.name}</h2>)
            )


        }</div>

        </>
    )

}