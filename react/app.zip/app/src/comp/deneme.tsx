import {useState} from "react";
interface text{
    yazi:string
}




export function Deneme(){
const [metin,setMetin]=useState<text>({yazi:"Tıklayınız"})

    return  (

        <>
        <h2>
            {metin.yazi}
        </h2>
            <button onClick={()=>setMetin({yazi:"Tıklandı"})}>Tıkla</button>
        </>
    )
}