import React from "react";


interface kullanicilar {
    isim: string;
    numara: number;
}
const dize : Array<string> = ['Apple', 'Orange', 'Banana'];

const kullanici:kullanicilar={
    isim:"ali",
    numara:16
}




export function Test(){


    return (
        <>
            <h1>{kullanici.isim}</h1>
            <h1>{kullanici.numara}</h1>
        </>

    );
}



