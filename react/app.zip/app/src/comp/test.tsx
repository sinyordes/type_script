import React from "react";


interface kullanicilar {
    isim: string;
    numara?: number;
}
const dize : Array<string> = ['Apple', 'Orange', 'Banana'];

const kullanici:kullanicilar={
    isim:"test",
    numara:16
}

const kullanici2:kullanicilar={
    isim:"test2"
}

export function Test(){


    return (
        <>
            <h1>{kullanici.isim}</h1>
            <h1>{kullanici.numara}</h1>
            <hr></hr>
            <h1>{kullanici2.isim}</h1>
            <hr></hr>
            <h3>{dize[2]}</h3>
        </>

    );
}



