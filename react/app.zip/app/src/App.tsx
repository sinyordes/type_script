import React from 'react';
import logo from './logo.svg';
import './App.css';
import {Test} from "./comp/test";

function App() {
  return (
    <div className="App">
     <Test />
    </div>
  );
}

export default App;
