import React from 'react';
import logo from './logo.svg';
import './App.css';
import {Test} from "./comp/test";
import {Deneme} from "./comp/deneme";
import {Deney} from "./comp/deney";
import {Yazi} from "./comp/deney";
import {ReduxComp} from "./comp/redux";

function App() {
  return (
    <div className="App">
        <Test />
        <Deneme />

        <hr></hr>
        <hr></hr>
       <ReduxComp />

    </div>
  );
}

export default App;
